<?php
// Mulakan sesi
session_start();

// Hapuskan semua data sesi
session_unset();

// Hancurkan sesi
session_destroy();

// Redirect ke halaman home selepas logout
header('Location: home.php');
exit();
?>
