<?php
// Sertakan fail config.php
require 'config.php';

// Mulakan sesi untuk mengenal pasti pengguna yang login
session_start();

// Semak jika pengguna sudah login
if (!isset($_SESSION['username'])) {
    // Jika tiada sesi aktif, redirect ke halaman login
    header('Location: login.php');
    exit();
}

// Dapatkan nama pengguna dari sesi
$username = $_SESSION['username'];

// Ambil maklumat pengguna dari database berdasarkan username
$sql = "SELECT * FROM users WHERE username = '$username'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Ambil data pengguna
    $row = $result->fetch_assoc();
    $full_name = $row['full_name'];
    $email = $row['email'];
} else {
    echo "User not found.";
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UiTM Student E-Profile - Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body {
        font-family: 'Poppins', sans-serif;
        background: radial-gradient(circle at top,rgb(34, 148, 194),rgb(15, 36, 153)); /* Latar belakang futuristik */
        margin: 0;
        padding: 0;
        color: #ffffff; /* Teks putih cerah */
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        overflow: hidden;
    }

    .dashboard-card {
        width: 100%;
        max-width: 600px;
        padding: 30px;
        background: linear-gradient(135deg, #1e1e1e, #2c2c2c); /* Latar belakang futuristik */
        border-radius: 15px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.7);
        text-align: center;
        position: relative;
    }

    .dashboard-card::after {
        content: '';
        position: absolute;
        top: -20%;
        left: -20%;
        width: 150%;
        height: 150%;
        background: radial-gradient(circle, rgba(255, 255, 255, 0.2), rgba(0, 0, 0, 0));
        animation: glow 8s infinite alternate ease-in-out;
    }

    @keyframes glow {
        0% {
            transform: scale(1);
        }
        100% {
            transform: scale(1.5);
        }
    }

    .dashboard-title {
        font-size: 2rem;
        font-weight: bold;
        color:rgb(220, 243, 17);
        text-transform: uppercase;
        margin-bottom: 20px;
        text-shadow: 3px 3px 10px rgba(15, 228, 228, 0.8);
    }

    .dashboard-details {
        font-size: 1.1rem;
        color: #ffeaa7;
        line-height: 1.6;
        margin-bottom: 15px;
    }

    .btn-logout {
        position: relative;
        z-index: 9999; /* Pastikan butang di atas semua elemen lain */
        width: 100%;
        background: linear-gradient(90deg, #ff0080, #ff6f61); /* Gradasi neon */
        color: #ffffff;
        padding: 12px 20px;
        font-size: 1.2rem;
        font-weight: bold;
        border: none;
        border-radius: 50px;
        text-transform: uppercase;
        box-shadow: 0 8px 20px rgba(255, 0, 128, 0.7);
        transition: all 0.3s ease-in-out;
        cursor: pointer;
    }

    .btn-logout:hover {
        background: linear-gradient(90deg, #ff6f61, #ff8c00); /* Warna hover */
        box-shadow: 0 15px 30px rgba(255, 105, 180, 0.9);
        transform: translateY(-5px);
    }

    /* Responsive */
    @media (max-width: 768px) {
        .dashboard-card {
            padding: 20px;
        }

        .dashboard-title {
            font-size: 1.5rem;
        }

        .btn-logout {
            font-size: 1rem;
            padding: 10px 15px;
        }
    }
</style>

</head>
<body>
    <div class="dashboard-card">
        <h2 class="dashboard-title">Welcome to Your UiTM E-Profile, <?php echo htmlspecialchars($full_name); ?>!</h2>

        <div class="dashboard-details">
            <strong>Username:</strong> <?php echo htmlspecialchars($username); ?>
        </div>
        <div class="dashboard-details">
            <strong>Full Name:</strong> <?php echo htmlspecialchars($full_name); ?>
        </div>
        <div class="dashboard-details">
            <strong>Email:</strong> <?php echo htmlspecialchars($email); ?>
        </div>

        <div class="d-grid">
            <!-- Button untuk logout -->
            <a href="logout.php" class="btn btn-logout">Log Out</a>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
