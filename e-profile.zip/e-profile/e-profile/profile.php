<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Profile List</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">
    <style>
    body {
        font-family: 'Poppins', sans-serif;
        background: radial-gradient(circle at top, #000000, #1a1a1a);
        margin: 0;
        padding: 20px;
        color: #ffffff;
        display: flex;
        justify-content: center;
        align-items: flex-start;
        flex-direction: column;
        min-height: 100vh;
        overflow-x: hidden;
    }

    .top-space {
        height: 80px;
    }

    .profile-list {
        width: 90%; /* Lebar total untuk memuat desain */
        max-width: 1200px; /* Batas maksimal pada layar besar */
        margin: 0 auto; /* Otomatis center secara horizontal */
        display: grid;
        grid-template-columns: repeat(3, 1fr); /* 3 kolom default */
        gap: 30px; /* Jarak antar profil */
        justify-items: center; /* Posisi profil tetap di tengah */
    }

    .profile-container {
        background: linear-gradient(135deg, #1e1e1e, #2c2c2c);
        padding: 20px;
        border-radius: 15px;
        box-shadow: 0 15px 30px rgba(0, 0, 0, 0.8);
        color: #ffffff;
        text-align: center;
        font-size: 1rem;
        width: 100%;
        max-width: 350px;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .profile-container:hover {
        transform: scale(1.05);
        box-shadow: 0 20px 40px rgba(255, 105, 180, 0.7);
    }

    .profile-header img {
        border-radius: 50%;
        width: 100px;
        height: 100px;
        object-fit: cover;
        border: 4px solid #ff8c00;
        background-color: #1a1a1a;
        box-shadow: 0 5px 15px rgba(255, 105, 180, 0.7);
    }

    .profile-header h3 {
        font-size: 1.5rem;
        font-weight: bold;
        color: #ff8c00;
        margin-top: 10px;
    }

    .profile-header p {
        font-size: 1rem;
        color: #ffeaa7;
        margin-top: 5px;
    }

    .profile-details {
        margin-top: 15px;
        text-align: left;
    }

    .profile-details p {
        font-size: 0.95rem;
        color: #ffeaa7;
        margin-bottom: 8px;
    }

    .btn-container {
        display: flex;
        justify-content: space-between;
        margin-top: 15px;
    }

    .btn-edit, .btn-save, .btn-back {
        padding: 10px 20px;
        background: linear-gradient(90deg, #ff0080, #ff6f61);
        color: white;
        border-radius: 50px;
        text-decoration: none;
        font-size: 0.85rem;
        font-weight: bold;
        text-transform: uppercase;
        cursor: pointer;
        border: none;
    }

    .btn-edit:hover, .btn-save:hover, .btn-back:hover {
        background: linear-gradient(90deg, #ff6f61, #ff8c00);
    }

    /* Responsif */
    @media screen and (max-width: 768px) {
        .profile-list {
            grid-template-columns: 1fr 1fr;
        }
    }

    @media screen and (max-width: 500px) {
        .profile-list {
            grid-template-columns: 1fr;
        }
    }
</style>


</head>
<body>

    <!-- Extra space at the top -->
    <div class="top-space"></div>

    <div class="profile-list">
    <!-- Profile 1 -->
    <div class="profile-container">
            <div class="profile-header">
                <img src="images/Profile.jpeg" alt="Afandi's Profile Picture">
                <h3>Muhammad Afandi</h3>
                <p>UiTM Student | Information System Management</p>
            </div>
            <div class="profile-details">
                <p><strong>Full Name:</strong> Muhammad Afandi Bin Osman </p>
                <p><strong>Student ID:</strong> 2024545209 </p>
                <p><strong>Email:</strong> 2024545209@student.uitm.edu.my</p>
                <p><strong>Phone:</strong> +60 1114188217</p>
            </div>
            <div class="btn-container">
                <a href="edit-profile.php?id=2024545209" class="btn-edit">Edit</a>
                <a href="home.php" class="btn-back">Back</a>
            </div>
        </div>

        <!-- Profile 2 -->
        <div class="profile-container">
            <div class="profile-header">
                <img src="images/Kamarul 1.jpg" alt="Kamarul's Profile Picture">
                <h3>Kamarul Azizul</h3>
                <p>UiTM Student | Information System Management</p>
            </div>
            <div class="profile-details">
                <p><strong>Full Name:</strong> Kamarul Azizul Bin Mohd</p>
                <p><strong>Student ID:</strong> 2024907845</p>
                <p><strong>Email:</strong> 2024907845@student.uitm.edu.my</p>
                <p><strong>Phone:</strong> +60 179849788</p>
            </div>
            <div class="btn-container">
                <a href="edit-profile.php?id=2024907845" class="btn-edit">Edit</a>
                <a href="home.php" class="btn-back">Back</a>
            </div>
        </div>

        <!-- Profile 3 -->
        <div class="profile-container">
            <div class="profile-header">
                <img src="images/Imran 1.jpg" alt="Imran's Profile Picture">
                <h3>Imran Haikal</h3>
                <p>UiTM Student | Information System Management</p>
            </div>
            <div class="profile-details">
                <p><strong>Full Name:</strong> Imran Haikal Bin Ismail</p>
                <p><strong>Student ID:</strong> 2024901234</p>
                <p><strong>Email:</strong> 2024901234@student.uitm.edu.my</p>
                <p><strong>Phone:</strong> +60 145678900</p>
            </div>
            <div class="btn-container">
                <a href="edit-profile.php?id=2024901234" class="btn-edit">Edit</a>
                <a href="home.php" class="btn-back">Back</a>
            </div>
        </div>

        <!-- Profile 4 -->
        <div class="profile-container">
            <div class="profile-header">
                <img src="images/Shakir 1.jpg" alt="Shakir's Profile Picture">
                <h3>Abdul Shakir</h3>
                <p>UiTM Student | Information System Management</p>
            </div>
            <div class="profile-details">
                <p><strong>Full Name:</strong> Abdul Shakir Hakim Bin Abdul Mutalib</p>
                <p><strong>Student ID:</strong> 2024905678</p>
                <p><strong>Email:</strong> 2024905678@student.uitm.edu.my</p>
                <p><strong>Phone:</strong> +60 138900234</p>
            </div>
            <div class="btn-container">
                <a href="edit-profile.php?id=2024905678" class="btn-edit">Edit</a>
                <a href="home.php" class="btn-back">Back</a>
            </div>
        </div>

        <!-- Profile 5 -->
        <div class="profile-container">
            <div class="profile-header">
                <img src="images/Fakhrul 1.jpg" alt="Fakhrul's Profile Picture">
                <h3>Fakhrul Naim</h3>
                <p>UiTM Student | Information System Management</p>
            </div>
            <div class="profile-details">
                <p><strong>Full Name:</strong> Fakhrul Naim Bin Ihsan</p>
                <p><strong>Student ID:</strong> 2024908765</p>
                <p><strong>Email:</strong> 2024908765@student.uitm.edu.my</p>
                <p><strong>Phone:</strong> +60 178234567</p>
            </div>
            <div class="btn-container">
                <a href="edit-profile.php?id=2024908765" class="btn-edit">Edit</a>
                <a href="home.php" class="btn-back">Back</a>
            </div>
        </div>

        <!-- Profile 6 -->
        <div class="profile-container">
            <div class="profile-header">
                <img src="images/Aqif 1.jpg" alt="Aqif's Profile Picture">
                <h3>Aqif Haikal</h3>
                <p>UiTM Student | Information System Management</p>
            </div>
            <div class="profile-details">
                <p><strong>Full Name:</strong> Aqif Haikal Bin Khairuddin</p>
                <p><strong>Student ID:</strong> 2024901230</p>
                <p><strong>Email:</strong> 2024901230@student.uitm.edu.my</p>
                <p><strong>Phone:</strong> +60 112233445</p>
            </div>
            <div class="btn-container">
                <a href="edit-profile.php?id=2024901230" class="btn-edit">Edit</a>
                <a href="home.php" class="btn-back">Back</a>
            </div>
        </div>
    </div>

</body>
</html> 