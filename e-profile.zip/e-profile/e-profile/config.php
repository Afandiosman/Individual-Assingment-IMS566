<?php
// Maklumat sambungan ke pangkalan data
$servername = "localhost";  // Hos, biasanya "localhost"
$username = "root";         // Nama pengguna MySQL (default: root)
$password = "";             // Kata laluan MySQL (default: kosong untuk pelayan tempatan)
$database = "uitm_e_profile"; // Nama pangkalan data

// Sambungan ke MySQL menggunakan mysqli
$conn = new mysqli($servername, $username, $password, $database);

// Periksa sambungan
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
