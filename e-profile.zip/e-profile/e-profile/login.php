<?php
// Sertakan fail config.php

session_start(); // Mulakan sesi

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Semak jika pengguna wujud
    $sql = "SELECT * FROM users WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Semak kata laluan
        if (password_verify($password, $row['password_hash'])) {
            $_SESSION['username'] = $username; // Simpan pengguna dalam sesi
            header('Location: dashboard.php'); // Redirect ke dashboard selepas login berjaya
            exit(); // Pastikan tiada kod lain yang dilaksanakan selepas redirect
        } else {
            echo "Incorrect password!";
        }
    } else {
        echo "No user found with that username.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UiTM Student E-Profile - Login</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body {
        background: radial-gradient(circle at top, #000000, #1a1a1a); /* Latar belakang futuristik */
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
        font-family: 'Poppins', sans-serif;
        color: #ffffff;
        overflow-x: hidden;
    }

    .login-card {
        width: 100%;
        max-width: 750px;
        padding: 30px;
        background: linear-gradient(135deg, #ff0080, #ff6f61, #ff8c00); /* Gradasi futuristik */
        border-radius: 12px;
        box-shadow: 0 8px 20px rgba(255, 0, 128, 0.7); /* Bayangan neon */
        text-align: center;
        position: relative;
        overflow: hidden;
    }

    .login-card::after {
    content: '';
    position: absolute;
    top: -20%;
    left: -20%;
    width: 150%;
    height: 150%;
    background: radial-gradient(circle, rgba(255, 255, 255, 0.2), rgba(0, 0, 0, 0));
    animation: glow 8s infinite alternate ease-in-out;
    pointer-events: none; /* Solusi untuk masalah ini */
}


    @keyframes glow {
        0% {
            transform: scale(1);
        }
        100% {
            transform: scale(1.5);
        }
    }

    .login-title {
        font-size: 2rem;
        font-weight: bold;
        margin-bottom: 25px;
        color: #ffffff;
        text-transform: uppercase;
        text-shadow: 3px 3px 10px rgba(255, 0, 128, 0.8);
    }

    .form-label {
        font-size: 0.95rem;
        font-weight: 500;
        color: #ffeaa7; /* Warna emas */
        text-align: left;
        display: block;
        margin-bottom: 8px;
    }

    .form-control {
        border: none;
        background: #1a1a1a; /* Hitam pekat */
        border-radius: 8px;
        padding: 12px 15px;
        font-size: 1rem;
        color: #ffeaa7; /* Warna emas */
        box-shadow: inset 0 0 5px rgba(255, 0, 128, 0.5);
        transition: all 0.3s ease-in-out;
    }

    .form-control:focus {
        outline: none;
        box-shadow: 0 0 10px rgba(255, 105, 180, 0.7); /* Efek glow */
    }

    .btn-custom {
        display: inline-block;
        width: 100%;
        padding: 12px 20px;
        font-size: 1rem;
        font-weight: bold;
        background: linear-gradient(90deg, #ff0080, #ff6f61);
        color: #fff;
        border: none;
        border-radius: 50px;
        transition: all 0.4s ease-in-out;
        margin-top: 20px;
        text-transform: uppercase;
    }

    .btn-custom:hover {
        background: linear-gradient(90deg, #ff6f61, #ff8c00);
        box-shadow: 0 10px 30px rgba(255, 105, 180, 0.9); /* Bayangan neon */
        transform: scale(1.1);
    }

    .link-text {
        font-size: 0.9rem;
        margin-top: 15px;
        color: #ffeaa7; /* Warna emas */
        text-align: center;
    }

    .link-text a {
        color: #ff6f61;
        text-decoration: none;
        font-weight: 600;
    }

    .link-text a:hover {
        text-decoration: underline;
        color: #ff8c00;
    }

    @media (max-width: 768px) {
        .login-card {
            padding: 20px;
        }
        .btn-custom {
            font-size: 0.9rem;
        }
    }
</style>

</head>
<body>
<div class="login-card">
    <h2 class="login-title">UiTM Student E-Profile</h2>
    <form method="POST">
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" name="username" id="username" placeholder="Enter your username" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" name="password" id="password" placeholder="Enter your password" required>
        </div>
        <div class="d-grid">
            <button type="submit" class="btn btn-custom">Log In</button>
        </div>
    </form>
    <div class="d-grid mt-3">
        <button type="button" class="btn btn-custom" onclick="goBack()">Back</button>
    </div>
    <div class="text-center mt-3">
        <small>Don't have an account? <a href="signup.php">Sign up here</a>.</small>
    </div>
</div>

<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

<!-- Tambah Fungsi Back -->
<script>
    function goBack() {
        window.history.back(); // Navigasi ke halaman sebelumnya
    }
</script>



</body>
</html>
