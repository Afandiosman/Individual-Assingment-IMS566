<?php
// Sambung ke database atau fail untuk mendapatkan maklumat pelajar
// Anda boleh gunakan $_GET untuk mendapatkan ID pelajar, contohnya: $_GET['id']
$id = $_GET['id'];

// Masukkan kod untuk menarik data pelajar berdasarkan ID di sini
// Contoh: gunakan query untuk mendapatkan maklumat pelajar berdasarkan ID

// Simulasi data pelajar untuk contoh ini
$student_data = [
    'name' => 'Kamarul Azizul',
    'student_id' => '2024907845',
    'email' => '2024907845@student.uitm.edu.my',
    'phone' => '+60 179849788'


];

// Semak jika borang telah dihantar
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari borang
    $name = $_POST['name'];
    $student_id = $_POST['student_id'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    // Masukkan kod untuk menyimpan perubahan ke pangkalan data atau fail di sini
    // Contoh: Update data dalam pangkalan data

    // Selepas perubahan disimpan, alihkan pengguna kembali ke halaman profil
    header("Location: profile.php?id=" . $id);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">
    <style>
    /* Gunakan gaya yang sama seperti pada halaman utama */
    body {
        font-family: 'Poppins', sans-serif;
        background: radial-gradient(circle at top, #000000, #1a1a1a);
        color: #ffffff;
        display: flex;
        justify-content: center;
        align-items: flex-start;
        flex-direction: column;
        padding: 20px;
        margin-top: 50px; /* Tambah ruang di atas */
    }

    .form-container {
        background: linear-gradient(135deg, #1e1e1e, #2c2c2c);
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.7);
        color: #ffffff;
        width: 100%;
        max-width: 600px;
    }

    .form-container input {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        background-color: #333;
        border: none;
        border-radius: 8px;
        color: #fff;
    }

    .form-container button {
        padding: 10px 20px;
        background: linear-gradient(90deg, #ff0080, #ff6f61);
        color: white;
        border-radius: 50px;
        font-size: 1rem;
        cursor: pointer;
        border: none;
    }

    .form-container button:hover {
        background: linear-gradient(90deg, #ff6f61, #ff8c00);
    }
</style>

</head>
<body>

    <div class="form-container">
        <h2>Edit Profile</h2>
        <form method="POST" action="">
            <label for="name">Full Name:</label>
            <input type="text" id="name" name="name" value="<?php echo $student_data['name']; ?>" required>

            <label for="student_id">Student ID:</label>
            <input type="text" id="student_id" name="student_id" value="<?php echo $student_data['student_id']; ?>" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo $student_data['email']; ?>" required>

            <label for="phone">Phone:</label>
            <input type="tel" id="phone" name="phone" value="<?php echo $student_data['phone']; ?>" required>

            <button type="submit">Save Changes</button>
        </form>
    </div>

</body>
</html>
