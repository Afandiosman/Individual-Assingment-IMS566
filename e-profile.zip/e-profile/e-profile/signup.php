<?php
// Sertakan fail config.php

// Mula proses borang
$error_message = "";  // Penyimpan mesej kesalahan

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Semak jika borang dihantar dengan data yang diperlukan
    if (isset($_POST['username'], $_POST['full_name'], $_POST['email'], $_POST['password'], $_POST['confirmPassword']) && 
        !empty($_POST['username']) && !empty($_POST['full_name']) && !empty($_POST['email']) && 
        !empty($_POST['password']) && !empty($_POST['confirmPassword'])) {

        // Ambil data dari borang
        $username = $_POST['username'];
        $full_name = $_POST['full_name'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $confirmPassword = $_POST['confirmPassword'];

        // Pastikan kata laluan dan pengesahan kata laluan sepadan
        if ($password !== $confirmPassword) {
            $error_message = "Passwords do not match. Please try again.";
        } else {
            // Hash kata laluan
            $password_hash = password_hash($password, PASSWORD_DEFAULT);

            // Semak jika pengguna sudah wujud
            $check_user_sql = "SELECT * FROM users WHERE username = ? OR email = ?";
            $stmt->bind_param("ss", $username, $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $error_message = "Username or email already exists. Please choose another.";
            } else {
                // Masukkan pengguna baru ke dalam jadual
                $insert_sql = "INSERT INTO users (username, full_name, email, password_hash) VALUES (?, ?, ?, ?)";
                $stmt = $conn->prepare($insert_sql);
                $stmt->bind_param("ssss", $username, $full_name, $email, $password_hash);
                if ($stmt->execute()) {
                    $error_message = "Signup successful!";
                } else {
                    $error_message = "Error: " . $stmt->error;
                }
            }
        }
    } else {
        $error_message = "All fields are required.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UiTM Student E-Profile - Sign Up</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body {
        font-family: 'Poppins', sans-serif;
        background: radial-gradient(circle at top, #000000, #1a1a1a); /* Latar belakang futuristik */
        margin: 0;
        padding: 0;
        color: #ffffff; /* Teks putih cerah */
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        overflow-x: hidden;
    }

    .signup-card {
        width: 90%; /* Kurangkan lebar supaya lebih kecil */
        max-width: 750px; /* Lebar maksimum lebih kecil */
        padding: 30px;
        background: linear-gradient(135deg, #1e1e1e, #2c2c2c); /* Card futuristik */
        border-radius: 15px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.7);
        position: relative;
        color: #ffffff;
        margin-top: 350px; /* Tambah ruang atas */
    }

    .signup-title {
        font-size: 2rem;
        font-weight: bold;
        text-align: center;
        color: #ff8c00;
        margin-bottom: 20px;
        text-shadow: 3px 3px 10px rgba(255, 0, 128, 0.8);
    }

    .form-label {
        font-size: 1rem;
        font-weight: 500;
        margin-bottom: 10px;
        display: block;
        color: #ffeaa7;
    }

    .form-control {
        width: 100%;
        border: none;
        border-radius: 8px;
        padding: 12px 15px;
        font-size: 1rem;
        margin-bottom: 20px;
        background: #1a1a1a;
        color: #ffffff;
        box-shadow: inset 0 0 10px rgba(255, 105, 180, 0.3);
        transition: all 0.3s ease;
    }

    .form-control:focus {
        border: 2px solid #ff8c00;
        outline: none;
        box-shadow: 0 0 10px rgba(255, 105, 180, 0.7);
    }

    .btn-custom {
        background: linear-gradient(90deg, #ff0080, #ff6f61);
        color: #fff;
        border: none;
        padding: 12px 25px;
        font-size: 1.2rem;
        font-weight: bold;
        border-radius: 50px;
        transition: all 0.4s ease-in-out;
        display: block;
        width: 100%;
        text-align: center;
        text-transform: uppercase;
    }

    .btn-custom:hover {
        background: linear-gradient(90deg, #ff6f61, #ff8c00);
        box-shadow: 0 10px 30px rgba(255, 105, 180, 0.9);
        transform: scale(1.05);
    }

    .alert {
        background: linear-gradient(135deg, #ff0080, #ff6f61, #ff8c00);
        color: #ffffff;
        padding: 15px;
        border-radius: 10px;
        text-align: center;
        font-size: 1rem;
        font-weight: bold;
        margin-bottom: 20px;
        box-shadow: 0 5px 15px rgba(255, 0, 128, 0.7);
    }

    /* Responsive */
    @media (max-width: 768px) {
        .signup-card {
            padding: 20px;
        }
        .signup-title {
            font-size: 1.8rem;
        }
        .btn-custom {
            font-size: 1rem;
        }
    }
</style>

</head>
<body>
    <div class="signup-card">
        <h2 class="signup-title">Create Your UiTM E-Profile Account</h2>

        <!-- Tunjukkan mesej kesalahan jika ada -->
        <?php if ($error_message != ""): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label for="fullName" class="form-label">Full Name</label>
                <input type="text" class="form-control" name="full_name" id="fullName" placeholder="Enter your full name" required>
            </div>
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" name="username" id="username" placeholder="Enter a unique username" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email Address</label>
                <input type="email" class="form-control" name="email" id="email" placeholder="Enter your email address" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" name="password" id="password" placeholder="Enter a secure password" required>
            </div>
            <div class="mb-3">
                <label for="confirmPassword" class="form-label">Confirm Password</label>
                <input type="password" class="form-control" name="confirmPassword" id="confirmPassword" placeholder="Re-enter your password" required>
            </div>
            <div class="d-grid">
                <button type="submit" class="btn btn-custom">Sign Up</button>
            </div>
            <div class="d-grid mt-3">
            <a href="home.php" class="btn btn-custom">Back</a>
            </div>

        </form>


        <div class="text-center mt-3">
            <small>Already have an account? <a href="login.php">Log in here</a>.</small>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>


    <!-- Tambah Fungsi Back -->
<script>
    function goBack() {
        window.history.back(); // Navigasi ke halaman sebelumnya
    }

<script>
</body>
</html>
