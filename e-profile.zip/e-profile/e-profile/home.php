<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UiTM Student E-Profile - Home</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
    body {
        font-family: 'Poppins', sans-serif;
        background: radial-gradient(circle at top, #4b0082, #1a1a1a); /* Latar belakang futuristik */
        margin: 0;
        padding: 0;
        color: #ffffff; /* Teks putih cerah */
        overflow-x: hidden;
    }

    /* Navbar */
    .navbar {
        background: linear-gradient(90deg, #800080, #ffdd00); /* Gradasi neon ungu ke kuning */
        padding: 1rem 2rem;
        box-shadow: 0 5px 15px rgba(255, 221, 0, 0.5);
    }
    .navbar-brand, .nav-link {
        color: #ffffff !important;
        font-weight: bold;
        text-transform: uppercase;
        font-size: 1.2rem;
        text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.8);
    }
    .nav-link:hover {
        color: #ffdd00 !important;
        text-decoration: underline;
    }

    /* Hero Section */
    .hero-section {
        text-align: center;
        padding: 140px 20px;
        background: linear-gradient(135deg, #800080, #ffdd00, #4b0082);
        color: #ffffff;
        position: relative;
        border-bottom: 5px solid #ffd700;
        overflow: hidden;
    }
    .hero-section::after {
        content: '';
        position: absolute;
        top: -20%;
        left: -20%;
        width: 150%;
        height: 150%;
        background: radial-gradient(circle, rgba(255, 255, 255, 0.2), rgba(0, 0, 0, 0));
        animation: glow 8s infinite alternate ease-in-out;
    }
    @keyframes glow {
        0% {
            transform: scale(1);
        }
        100% {
            transform: scale(1.5);
        }
    }
    .hero-section h1 {
        font-size: 4.5rem;
        margin-bottom: 20px;
        font-weight: 900;
        text-transform: uppercase;
        text-shadow: 5px 5px 15px rgba(0, 0, 0, 0.8);
        animation: zoomIn 1.5s ease-out;
    }
    .hero-section p {
        font-size: 1.7rem;
        font-weight: 400;
        margin-top: 10px;
        color: #ffdd00;
    }

    @keyframes zoomIn {
        0% {
            transform: scale(0.8);
            opacity: 0;
        }
        100% {
            transform: scale(1);
            opacity: 1;
        }
    }

    /* Content Section */
    .content-section {
        padding: 80px 40px;
        background: linear-gradient(to bottom, #1e1e1e, #2c2c2c);
        border-radius: 15px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.7);
        color: #ffffff;
        margin-top: -80px;
        z-index: 2;
        position: relative;
    }
    .content-section h2 {
        font-size: 2.8rem;
        font-weight: bold;
        text-align: center;
        color: #ffdd00;
        margin-bottom: 40px;
        text-shadow: 3px 3px 10px rgba(128, 0, 128, 0.8);
    }

    .card {
        background: linear-gradient(135deg, #800080, #4b0082, #ffdd00);
        border-radius: 10px;
        box-shadow: 0 8px 20px rgba(255, 221, 0, 0.7);
        padding: 2rem;
        margin-bottom: 20px;
        transition: all 0.3s ease;
        color: #ffffff;
        position: relative;
    }

    .card:hover {
        transform: translateY(-10px);
        box-shadow: 0 15px 30px rgba(255, 221, 0, 0.9);
    }

    .card-title {
        font-size: 1.8rem;
        font-weight: bold;
        color: #ffffff;
        text-transform: uppercase;
        margin-bottom: 15px;
    }

    .card-text {
        font-size: 1rem;
        line-height: 1.5;
        color: #ffdd00;
    }

    .btn-custom {
        background: linear-gradient(90deg, #800080, #ffdd00);
        color: #fff;
        border: none;
        padding: 12px 25px;
        font-size: 1.2rem;
        font-weight: bold;
        border-radius: 50px;
        transition: all 0.4s ease-in-out;
        display: inline-block;
        text-align: center;
        text-transform: uppercase;
    }

    .btn-custom:hover {
        background: linear-gradient(90deg, #ffdd00, #800080);
        box-shadow: 0 10px 30px rgba(255, 105, 180, 0.9);
        transform: scale(1.1);
    }

    /* Footer */
    .footer {
        background: #121212;
        color: #ffffff;
        padding: 20px 0;
        text-align: center;
        font-size: 1.2rem;
        border-top: 3px solid #ffdd00;
    }

    .footer p {
        margin: 0;
        color: #ffdd00;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .hero-section h1 {
            font-size: 3rem;
        }
        .content-section {
            padding: 40px 20px;
        }
        .card {
            padding: 1.5rem;
        }
        .btn-custom {
            width: 100%;
        }
    }
</style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="home.php">UiTM E-Profile</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="signup.php">Sign Up</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="hero-section">
        <h1>Welcome to UiTM Student E-Profile</h1>
        <p>Your one-stop solution to manage and explore student profiles with ease.</p>
    </div>

    <!-- Content Section -->
    <div class="content-section container">
        <h2 class="text-center mb-4">Explore Features</h2>
        <div class="row">
            <div class="col-md-4">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">Student Profiles</h5>
                        <p class="card-text">View detailed profiles of UiTM students, including their academic and personal information.</p>
                        <a href="profile.php" class="btn btn-primary">View Profiles</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">Secure Login</h5>
                        <p class="card-text">Log in securely to access and manage your personal profile information.</p>
                        <a href="login.php" class="btn btn-primary">Log In</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">Easy Registration</h5> 
                        <p class="card-text">Sign up quickly and get started with your UiTM E-Profile in just a few steps.</p> 
                        <a href="signup.php" class="btn btn-primary">Sign Up</a> </div> </div> </div> </div> </div> 
                        <!-- Footer --> <div class="footer"> <p>&copy; <?php echo date("Y"); 
                        ?> UiTM E-Profile. All Rights Reserved.</p> </div> 
                        <!-- Bootstrap JS Bundle --> 
                         <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script> 
                    </body> </html>